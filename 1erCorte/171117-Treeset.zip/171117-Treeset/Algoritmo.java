import java.util.TreeSet;

public class Algoritmo {
    public void conferenciaAlgoritmo(TreeSet<String> algo){
        algo.add("Alexis");
        algo.add("Ramirez");
        algo.add("Sandra");
        algo.add("Julian");
        algo.add("Rox");
    }
    
}