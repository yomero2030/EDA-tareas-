import java.util.TreeSet;

public class Matematicas {
    
    public void ConferenciaMatematicas(TreeSet<String> mate){
        mate.add("Elena");
        mate.add("Pedro");
        mate.add("Juan");
        mate.add("Pablo");
        mate.add("Ana");
    }

}