import java.util.TreeSet;

public class ProgramacionVS {
    
    public void conferenciaProgramacion(TreeSet<String> pVsiual){
        pVsiual.add("Fabian");
        pVsiual.add("Adrian");
        pVsiual.add("Luis");
        pVsiual.add("David");
        pVsiual.add("Maria");
    }
}